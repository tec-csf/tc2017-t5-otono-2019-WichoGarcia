#ifndef PRISMARECT_H
#define PRISMARECT_H

#include <QDialog>
#include <QtGui>
#include <QtCore>

namespace Ui {
class prismaRect;
}

class prismaRect : public QDialog
{
    Q_OBJECT

public:
    explicit prismaRect(QWidget *parent = 0);
    ~prismaRect();

protected:
     void paintEvent(QPaintEvent *e);
     void drawprismaRect(QPainter &painter);

private slots:
      void on_pushButton_clicked();

     void on_pushButton_2_clicked();

     void on_pushButton_3_clicked();

     void on_pushButton_4_clicked();

     void on_pushButton_5_clicked();

     void on_pushButton_6_clicked();

     void on_pushButton_7_clicked();

private:
    Ui::prismaRect *ui;
    bool draw = false;
    double midX, midY;
    QVector<QTransform> qVecTrans;
};

#endif // PRISMARECT_H
