#ifndef POLY_H
#define POLY_H

#include <QDialog>
#include <QtGui>
#include <QtCore>
namespace Ui {
class poly;
}

class poly : public QDialog
{
    Q_OBJECT

public:
    explicit poly(QWidget *parent = 0);
    ~poly();

protected:
     void paintEvent(QPaintEvent *e);
     void drawPoly(int lados, int rad,QPainter &painter);

private:
    Ui::poly *ui;
    bool draw = false;
    int lados, radio;
    double midX, midY;
    QVector<QTransform> qVecTrans;

private slots:
      void on_pushButton_clicked();

     void on_pushButton_2_clicked();

     void on_pushButton_3_clicked();

     void on_pushButton_4_clicked();

     void on_pushButton_5_clicked();

     void on_pushButton_6_clicked();

     void on_pushButton_7_clicked();
};

#endif // POLY_H
