#include "cube.h"
#include "ui_cube.h"
#include <QPainter>
#include <QMessageBox>
#include <math.h>

cube::cube(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::cube)
{
    ui->setupUi(this);
    midX = width()/2;
    midY = height()/2;
    QTransform center;
    center.translate(midX,midY);
    qVecTrans.push_back(center);
}

cube::~cube()
{
    delete ui;
}

void cube::paintEvent(QPaintEvent *e){
    QPainter painter(this);
    QPen pointPen(Qt::red);
    pointPen.setWidth(3);
    painter.setPen(pointPen);
    if (draw){
        for(int i=0; i<qVecTrans.size(); ++i){
            painter.setTransform(qVecTrans[i],true);
            drawcube(painter);
        }
    }
}

void cube::drawcube(QPainter &painter){
        painter.drawLine(-40, 40, 40, 40);
        painter.drawLine(-40, 40, -40, -40);
        painter.drawLine(40, 40, 40, -40);
        painter.drawLine(-40, -40, 40, -40);
        painter.drawLine(0, 0, 80, 0);
        painter.drawLine(0, 0, 0, -80);
        painter.drawLine(80, 0, 80, -80);
        painter.drawLine(0, -80, 80, -80);
        painter.drawLine(-40, 40, 0, 0);
        painter.drawLine(40, 40, 80, 0);
        painter.drawLine(-40, -40, 0, -80);
        painter.drawLine(40, -40, 80, -80);
}


void cube::on_pushButton_clicked()
{
    //Dibujar
    qVecTrans.clear();
    QTransform center;
    center.translate(midX,midY);
    qVecTrans.push_back(center);
    draw = !draw;
    update();
}

void cube::on_pushButton_2_clicked()
{
    //Trasladar
    QString x = ui->boxXinicio->toPlainText();
    QString y = ui->boxYinicio->toPlainText();
     if(!x.isEmpty() && !y.isEmpty()) {
       int xS = x.toInt();
       int yS = y.toInt();
       QTransform t;
       t.translate(xS, yS);
       qVecTrans.push_back(t);
     } else {
       QMessageBox msgBox;
       msgBox.setText("Favor de elegir traslacion");
       msgBox.exec();
     }
     update();
}

void cube::on_pushButton_3_clicked()
{
    //Rotar
    QString r = ui->boxGrados->toPlainText();
      if(!r.isEmpty()) {
        int rS = r.toInt();
        QTransform r;
        r.rotate(rS);
        qVecTrans.push_back(r);
      } else {
        QMessageBox msgBox;
        msgBox.setText("Favor de elegir angulo");
        msgBox.exec();
      }
    update();
}

void cube::on_pushButton_7_clicked()
{
    //Refl Vertical
    QTransform rv;
    rv.scale(1,-1);
    qVecTrans.push_back(rv);
    update();
}

void cube::on_pushButton_6_clicked()
{
    //Refl Horizontal
    QTransform rh;
    rh.scale(-1,1);
    qVecTrans.push_back(rh);
    update();
}

void cube::on_pushButton_4_clicked()
{
    //Zoom In
    QTransform zIn;
    zIn.scale(2,2);
    qVecTrans.push_back(zIn);
    update();
}

void cube::on_pushButton_5_clicked()
{
    //Zoom Out
    QTransform zOut;
    zOut.scale(0.5,0.5);
    qVecTrans.push_back(zOut);
    update();
}
