#ifndef PRISMATRIAN_H
#define PRISMATRIAN_H

#include <QDialog>
#include <QtGui>
#include <QtCore>
namespace Ui {
class prismaTrian;
}

class prismaTrian : public QDialog
{
    Q_OBJECT

public:
    explicit prismaTrian(QWidget *parent = 0);
    ~prismaTrian();

protected:
     void paintEvent(QPaintEvent *e);
     void drawprismaTrian(QPainter &painter);


private slots:
      void on_pushButton_clicked();

     void on_pushButton_2_clicked();

     void on_pushButton_3_clicked();

     void on_pushButton_4_clicked();

     void on_pushButton_5_clicked();

     void on_pushButton_6_clicked();

     void on_pushButton_7_clicked();

private:
    Ui::prismaTrian *ui;
    bool draw = false;
    double midX, midY;
    QVector<QTransform> qVecTrans;
};

#endif // PRISMATRIAN_H
