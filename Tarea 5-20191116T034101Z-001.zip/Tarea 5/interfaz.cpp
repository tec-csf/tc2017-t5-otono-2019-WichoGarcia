#include "interfaz.h"
#include "ui_interfaz.h"
#include <QMessageBox>

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_pushButton_clicked()
{
    arc a;
    a.setModal(true);
    a.exec();
}

void Dialog::on_pushButton_2_clicked()
{
    poly p;
    p.setModal(true);
    p.exec();
}

void Dialog::on_pushButton_3_clicked()
{
    cono c;
    c.setModal(true);
    c.exec();
}

void Dialog::on_pushButton_4_clicked()
{
    cube cu;
    cu.setModal(true);
    cu.exec();
}

void Dialog::on_pushButton_5_clicked()
{
    prismaRect pr;
    pr.setModal(true);
    pr.exec();
}

void Dialog::on_pushButton_6_clicked()
{
    prismaTrian pt;
    pt.setModal(true);
    pt.exec();
}





